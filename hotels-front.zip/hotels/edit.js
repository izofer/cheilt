var app = new Vue({
	el: '#app',
	data:{
		id:localStorage.getItem("id"),
		url:'http://localhost:8080/cheil/public',
		name:'',
		price:'',
		category:'',
		pictures:''
	},
	mounted(){
		this.initHotel()
	},
	methods:{
		initHotel(price){
			fetch(`${this.url}/api/hotels/${this.id}`,{
				method: "GET",
			})
			.then((response)=>{
				return response.json()
			})
			.then((hotel) => {
				this.name = hotel.data[0].HotelName
				this.price = this.formatNumber(hotel.data[0].Precio)
				this.category = hotel.data[0].Categoria
				this.pictures = hotel.data[0].Pictures
			})
			.catch((error)=>{
				console.log(error)
			})
		},
		formatNumber(num){
			return num.split('.').join('')
		},
		save()
		{
			this.$refs.text.innerHTML = ''

			let payload = {
				"name":this.name,
			    "category":this.category,
			    "price":this.price
			}

			fetch(`${this.url}/api/hotels/${this.id}`,{
				headers:{
					'Accept':'application/json',
					'Content-Type':'application/json'
				},
				method: "PUT",
				body:JSON.stringify(payload)
			})
			.then((response)=>{
				if(response.status === 401)
				{
					localStorage.removeItem('token')
					location.reload()
				}
				else
				{
					return response.json()
				}
			})
			.then((data)=>{
				this.$refs.text.innerHTML = `<h1>${data.data} <br/> <a href="crud.html">Go to Back</a> </h1>`
			})
			.catch((error)=>{
				console.log(error)
			})
		},
	}
})