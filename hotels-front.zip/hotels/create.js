var app = new Vue({
	el: '#app',
	data:{
		id:localStorage.getItem("id"),
		url:'http://localhost:8080/cheil/public',
		name:'',
		price:'',
		category:'',
		file1:'',
		file2:'',
		file3:''
	},
	methods:{
		formatNumber(num){
			return num.split('.').join('')
		},
		save()
		{
			this.$refs.text.innerHTML = ''

			let formData = new FormData()
			
			formData.append("name",this.name)
			formData.append("category",this.category)
			formData.append("price",this.price)
			formData.append("file1",this.file1)
			formData.append("file2",this.file2)
			formData.append("file3",this.file3)

			fetch(`${this.url}/api/hotels`,{
				headers:{},
				method: "POST",
				body:formData
			})
			.then((response)=>{
				if(response.status === 401)
				{
					localStorage.removeItem('id')
					location.reload()
				}
				else
				{
					return response.json()
				}
			})
			.then((data)=>{
				this.$refs.text.innerHTML = `<h1>${data.data} <br/> <a href="crud.html">Go to Back</a> </h1>`
			})
			.catch((error)=>{
				console.log(error)
			})
		},
		changeFiles()
		{
			if(this.$refs.file1.files != null)
			{
				this.file1 = this.$refs.file1.files[0]
			}

			if(this.$refs.file2.files != null)
			{
				this.file2 = this.$refs.file2.files[0]
			}

			if(this.$refs.file3.files != null)
			{
				this.file3 = this.$refs.file3.files[0]
			}
			
			console.log(this.file1)
		}
	}
})