var app = new Vue({
	el: '#app',
	data:{
		url:'http://localhost:8080/cheil/public',
		price:'desc',
		hotels:''
	},
	mounted(){
		this.initHotel()
	},
	methods:{
		initHotel(price){
			const url = `${this.url}/api/filter-hotel-price/${this.price}`

			fetch(`${url}`,{
				method: "GET",
			})
			.then((response)=>{
				return response.json()
			})
			.then((hotels) => {
				this.hotels = hotels.data
			})
			.catch((error)=>{
				console.log(error)
			})
		},
		showHotel(id){
			localStorage.setItem('id',id)
			location.href="score.html";
		}
	}
})