$('#options').css('visibility','hidden')
$(document).ready( function () {
    getData()
} );

function getData()
{
	const urlapi = 'http://localhost:8080/cheil/public'
	let   list = $('#injectData')

	fetch(`${urlapi}/api/hotels`)
	.then(response => response.json())
	.then(hotels => {
		let listHotels = hotels.data
		let elements = ''
		listHotels.forEach((hotels) => {

			let elements = `
				<tr>
					<td>${hotels.HotelID}</td>
					<td>${hotels.HotelName}</td>
					<td>${hotels.Categoria} 🌟</td>
					<td>$${hotels.Precio}</td>
					<td>
						<a href="#" class="edit" onClick="goEdit(${hotels.HotelID})">✏Editar</a> 
						<a href="#" class="edit" onClick="deletes(${hotels.HotelID})">♻Borrar</a> </td>
				</tr>
			`
			list.append(elements)
		})
		
		$('#table').DataTable({
			"ordering": false,
			responsive:true,
		})

		$('#options').css('visibility','visible')
	})
	.catch(error=>{
		console.log(error)
	})
}

function goEdit(id)
{
	localStorage.setItem("id",id)
	window.location = 'edit.html'
}

function deletes(id)
{
	const urlapi = 'http://localhost:8080/cheil/public'

	fetch(`${urlapi}/api/hotels/${id}`,{
		headers:{
			'Accept':'application/json',
			'Content-Type':'application/json'
		},
		method: "DELETE",
	})
	.then((response)=>{
		if(response.status === 401)
		{
			localStorage.removeItem('token')
			location.reload()
		}
		else
		{
			return response.json()
		}
	})
	.then((data)=>{
		let text = document.getElementById('text')
		text.innerHTML = `<h1>${data.data}</h1>`

		setTimeout((e)=>{
			window.location = 'crud.html'
		},3000)
	})
	.catch((error)=>{
		console.log(error)
	})
}